﻿$('#show-partial1').click(function () {
    $('#partial2').hide();
    $('#partial1').show();
});
$('#show-partial2').click(function () {
    $('#partial1').hide();
    $('#partial2').show();
});