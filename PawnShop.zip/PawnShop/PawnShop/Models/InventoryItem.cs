﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PawnShop.Models
{
   public abstract class InventoryItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public string Manufacturer { get; set; }
        public int ProductionYear { get; set; }
    }
    public enum Type { Sedan = 1, SUV = 2, Limousine, Truck, Pickup };
    public enum Condition { Mint = 1, Good = 2, Damaged };
    public class Vehicle : InventoryItem
    {
        public Type Type { get; set; }
        public Condition Condition { get; set; }
    }
    public enum Material { Gold = 1, Rubber = 2, Other };
    public class Watch : InventoryItem
    {
        public Material Material { get; set; }
    }
}