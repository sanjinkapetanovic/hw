﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PawnShop.Models;

namespace PawnShop.Controllers
{
    public class InventoryItemsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: InventoryItems
        public ActionResult Index(string searchBy, string search, string sortOrder)
        {
            List<InventoryItem> items = db.InventoryItems.ToList();

            if (searchBy == "Name")
            {
                items = items.Where(x => x.Name.StartsWith(search)).ToList();
            }
            else if (searchBy == "Price")
            {
                double searchTerm = Convert.ToDouble(search);
                items = items.Where(x => x.Price < searchTerm).ToList();
            }
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewBag.PriceSortParm = sortOrder == "Price" ? "price_desc" : "Price";
            switch (sortOrder)
            {
                case "name_desc":
                    items = items.OrderByDescending(s => s.Name).ToList();
                    break;
                case "Price":
                    items = items.OrderBy(s => s.Price).ToList();
                    break;
                case "price_desc":
                    items = items.OrderByDescending(s => s.Price).ToList();
                    break;
                default:
                    items = items.OrderBy(s => s.Name).ToList();
                    break;
            }
            return View(items);
        }

        // GET: InventoryItems/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vehicle vehicle = db.Vehicles.FirstOrDefault(x => x.Id == id);
            Watch watch = db.Watches.FirstOrDefault(x => x.Id == id);
            if (watch != null)
            {
                return RedirectToAction("../Watches/Details", new { id = watch.Id });
            }
            else if (vehicle != null)
            {
                return RedirectToAction("../Vehicles/Details", new { id = watch.Id });
            }
            else
            {
                return HttpNotFound();
            }
        }

        //GET: InventoryItems/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: InventoryItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Id,Name,Description,Price,Manufacturer,ProductionYear")] InventoryItem inventoryItem)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.InventoryItems.Add(inventoryItem);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(inventoryItem);
        //}
        //GET: InventoryItems/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vehicle vehicle = db.Vehicles.FirstOrDefault(x => x.Id == id);
            Watch watch = db.Watches.FirstOrDefault(x => x.Id == id);
            if (watch != null)
            {
                return RedirectToAction("../Watches/Edit", new { id = watch.Id });
            }
            else if (vehicle != null)
            {
                return RedirectToAction("../Vehicles/Edit", new { id = vehicle.Id });
            }
            else
            {
                return HttpNotFound();
            }
        }

        // POST: InventoryItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit([Bind(Include = "Id,Name,Description,Price,Manufacturer,ProductionYear")] InventoryItem inventoryItem)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(inventoryItem).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(inventoryItem);
        //}

        // GET: InventoryItems/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vehicle vehicle = db.Vehicles.FirstOrDefault(x => x.Id == id);
            Watch watch = db.Watches.FirstOrDefault(x => x.Id == id);
            if (watch != null)
            {
                return RedirectToAction("../Watches/Delete", new { id = watch.Id });
            }
            else if (vehicle != null)
            {
                return RedirectToAction("../Vehicles/Delete", new { id = watch.Id });
            }
            else
            {
                return HttpNotFound();
            }
        }

        //// POST: InventoryItems/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    InventoryItem inventoryItem = db.InventoryItems.Find(id);
        //    db.InventoryItems.Remove(inventoryItem);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}



        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
