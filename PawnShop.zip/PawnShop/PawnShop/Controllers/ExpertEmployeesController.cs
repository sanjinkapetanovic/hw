﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PawnShop.Models;

namespace PawnShop.Controllers
{
    public class ExpertEmployeesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: ExpertEmployees
        public ActionResult Index()
        {
            return View(db.ExpertEmployees.ToList());
        }

        // GET: ExpertEmployees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ExpertEmployee expertEmployee = db.ExpertEmployees.Find(id);
            if (expertEmployee == null)
            {
                return HttpNotFound();
            }
            return View(expertEmployee);
        }

        // GET: ExpertEmployees/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ExpertEmployees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Expertise,FirstName,LastName")] ExpertEmployee expertEmployee)
        {
            if (ModelState.IsValid)
            {
                db.ExpertEmployees.Add(expertEmployee);
                db.SaveChanges();
                return RedirectToAction("Index", "Employees");
            }

            return View(expertEmployee);
        }

        // GET: ExpertEmployees/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ExpertEmployee expertEmployee = db.ExpertEmployees.Find(id);
            if (expertEmployee == null)
            {
                return HttpNotFound();
            }
            return View(expertEmployee);
        }

        // POST: ExpertEmployees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Expertise,FirstName,LastName")] ExpertEmployee expertEmployee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(expertEmployee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Employees");
            }
            return View(expertEmployee);
        }

        // GET: ExpertEmployees/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ExpertEmployee expertEmployee = db.ExpertEmployees.Find(id);
            if (expertEmployee == null)
            {
                return HttpNotFound();
            }
            return View(expertEmployee);
        }

        // POST: ExpertEmployees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ExpertEmployee expertEmployee = db.ExpertEmployees.Find(id);
            db.ExpertEmployees.Remove(expertEmployee);
            db.SaveChanges();
            return RedirectToAction("Index", "Employees");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
