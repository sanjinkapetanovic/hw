﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PawnShop.Models
{
    public abstract class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get {return FirstName +" "+ LastName; } }
    }
    public class CasualEmployee : Employee
    {

    }
    public enum Expertise {AuctionServices= 1, DiamondAppraisal= 2, GadgetAppraisal, GoldAppraisal, JeweleryAppraisal}
    public class ExpertEmployee:Employee
    {
        public Expertise Expertise { get; set; }
    }
}