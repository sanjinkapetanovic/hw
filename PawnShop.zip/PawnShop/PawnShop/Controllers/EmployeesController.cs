﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PawnShop.Models;

namespace PawnShop.Controllers
{
    public class EmployeesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Employees
        public ActionResult Index()
        {
            return View(db.Employees.ToList());
        }

        // GET: Employees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CasualEmployee casual = db.CasualEmployees.FirstOrDefault(x => x.Id == id);
            ExpertEmployee expert = db.ExpertEmployees.FirstOrDefault(x => x.Id == id);
            if (casual != null)
            {
                return RedirectToAction("../CasualEmployees/Details", new { id = casual.Id });
            }
            else if (expert != null)
            {
                return RedirectToAction("../ExpertEmployees/Details", new { id = expert.Id });
            }
            else
            {
                return HttpNotFound();
            }
        }

        // GET: Employees/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee);
        }

        // GET: Employees/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CasualEmployee casual = db.CasualEmployees.FirstOrDefault(x => x.Id == id);
            ExpertEmployee expert = db.ExpertEmployees.FirstOrDefault(x => x.Id == id);
            if (casual != null)
            {
                return RedirectToAction("../CasualEmployees/Edit", new { id = casual.Id });
            }
            else if (expert != null)
            {
                return RedirectToAction("../ExpertEmployees/Edit", new { id = expert.Id });
            }
            else
            {
                return HttpNotFound();
            }
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        // GET: Employees/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CasualEmployee casual = db.CasualEmployees.FirstOrDefault(x => x.Id == id);
            ExpertEmployee expert = db.ExpertEmployees.FirstOrDefault(x => x.Id == id);
            if (casual != null)
            {
                return RedirectToAction("../CasualEmployees/Delete", new { id = casual.Id });
            }
            else if (expert != null)
            {
                return RedirectToAction("../ExpertEmployees/Delete", new { id = expert.Id });
            }
            else
            {
                return HttpNotFound();
            }
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee employee = db.Employees.Find(id);
            db.Employees.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
